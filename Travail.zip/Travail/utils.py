from math import sqrt


def moyenne(donnees):
    """Calcule la moyenne d'une liste de valeurs."""
    return sum(donnees) / len(donnees)


def variance(donnees):
    """Calcule la variance d'une liste de valeurs."""
    moy = moyenne(donnees)
    return sum((x - moy) ** 2 for x in donnees) / len(donnees)


def ecart_type(donnees):
    """Calcule l'écart-type d'une liste de valeurs."""
    return sqrt(variance(donnees))


def covariance(donnees_x, donnees_y):
    """Calcule la covariance entre deux listes de valeurs."""
    moy_x = moyenne(donnees_x)
    moy_y = moyenne(donnees_y)
    n = min(len(donnees_x), len(donnees_y))
    return sum((donnees_x[i] - moy_x) * (donnees_y[i] - moy_y) for i in range(n)) / n


def correlation(donnees_x, donnees_y):
    """Calcule le coefficient de corrélation (avec racine des écarts-types)."""
    cov = covariance(donnees_x, donnees_y)
    racine_sigma = sqrt(ecart_type(donnees_x) * ecart_type(donnees_y))
    return cov / racine_sigma


def correlation_bornee(donnees_x, donnees_y):
    """Calcule le coefficient de corrélation borné (Pearson)."""
    cov = covariance(donnees_x, donnees_y)
    sigma_produit = ecart_type(donnees_x) * ecart_type(donnees_y)
    return cov / sigma_produit


def matrice_covariance(liste_donnees):
    """Génère une matrice de covariance pour une liste de séries de données."""
    n = len(liste_donnees)
    return [[covariance(liste_donnees[i], liste_donnees[j]) for j in range(n)] for i in range(n)]