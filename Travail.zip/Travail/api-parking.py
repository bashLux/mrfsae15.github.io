import requests
import time
import json
from pathlib import Path
from datetime import datetime

# Configuration
NOM_FICHIER = "Donnee_SAE_Parking.json"
INTERVALLE_HEURES = 1
DUREE_JOURS = 30
API_URL = "https://portail-api-data.montpellier3m.fr/offstreetparking?limit=1000"


def convertir_temps(temps_unix: float) -> str:
    """Convertit un timestamp Unix en date lisible."""
    return datetime.fromtimestamp(temps_unix).strftime("%d/%m/%Y %H:%M:%S")


def recuperer_donnees_parking() -> list:
    """Récupère les données de l'API des parkings."""
    reponse = requests.get(API_URL)
    return reponse.json()


def analyser_parkings(data_parking: list, temps_actuel: str) -> tuple[list, dict]:
    """Analyse les données des parkings ouverts et calcule les statistiques."""
    resultats = []
    totaux = {"total": 0, "occupe": 0, "libre": 0}

    for parking in data_parking:
        if parking["status"]["value"] != "Open":
            continue

        total = parking["totalSpotNumber"]["value"]
        libres = parking["availableSpotNumber"]["value"]
        occupes = total - libres
        pourcent = round((occupes / total) * 100, 2)

        resultats.append({
            "id": parking["name"]["value"],
            "status": parking["status"]["value"],
            "temps": temps_actuel,
            "place": {
                "emplacement_total": total,
                "emplacement_occupe": occupes,
                "emplacement_disponible": libres,
                "occupation": f"{pourcent}%"
            }
        })

        totaux["total"] += total
        totaux["occupe"] += occupes
        totaux["libre"] += libres

    return resultats, totaux


def ajouter_stats_globales(resultats: list, totaux: dict, temps_actuel: str) -> None:
    """Ajoute les statistiques globales de Montpellier aux résultats."""
    pourcent_global = round((totaux["occupe"] / totaux["total"]) * 100, 2)
    resultats.append({
        "type": "Montpellier",
        "temps": temps_actuel,
        "place": {
            "emplacement_total": totaux["total"],
            "emplacement_occupe": totaux["occupe"],
            "emplacement_disponible": totaux["libre"],
            "occupation": f"{pourcent_global}%"
        }
    })


def sauvegarder_donnees(resultats: list, fichier: Path) -> None:
    """Sauvegarde les résultats dans le fichier JSON."""
    contenu = []
    if fichier.exists():
        try:
            contenu = json.loads(fichier.read_text(encoding="utf8"))
        except json.JSONDecodeError:
            contenu = []

    contenu.extend(resultats)
    fichier.write_text(json.dumps(contenu, indent=4, ensure_ascii=False), encoding="utf8")


def main():
    """Boucle principale de collecte des données."""
    intervalle_secondes = INTERVALLE_HEURES * 3600
    nb_mesures = (DUREE_JOURS * 24 * 3600) // intervalle_secondes
    fichier = Path(NOM_FICHIER)

    for i in range(int(nb_mesures)):
        temps_actuel = convertir_temps(time.time())
        data_parking = recuperer_donnees_parking()

        resultats, totaux = analyser_parkings(data_parking, temps_actuel)
        ajouter_stats_globales(resultats, totaux, temps_actuel)
        sauvegarder_donnees(resultats, fichier)

        print(f"Mesure parking {i + 1} enregistrée {temps_actuel}")

        if i < nb_mesures - 1:
            time.sleep(intervalle_secondes - 1)


if __name__ == "__main__":
    main()