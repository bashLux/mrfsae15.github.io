"""Monitoring des stations vélos de Montpellier."""

import json
import time
from datetime import datetime
from pathlib import Path

import requests

# Configuration
API_URL = "https://portail-api-data.montpellier3m.fr/bikestation?limit=1000"
FICHIER_SORTIE = Path("Donnée_SAE_velo.json")
INTERVALLE_HEURES = 1
DUREE_JOURS = 30


def formater_date(timestamp: float) -> str:
    """Convertit un timestamp Unix en date lisible."""
    return datetime.fromtimestamp(timestamp).strftime("%d/%m/%Y %H:%M:%S")


def recuperer_donnees_velos() -> list[dict]:
    """Récupère les données des stations vélos depuis l'API."""
    reponse = requests.get(API_URL)
    return reponse.json()


def analyser_stations(data: list[dict], temps: str) -> list[dict]:
    """Analyse les stations en service et calcule les statistiques."""
    resultats = []
    total_ville, occupees_ville, disponibles_ville = 0, 0, 0

    for station in data:
        if station["status"]["value"] != "working":
            continue

        total = station["totalSlotNumber"]["value"]
        disponibles = station["availableBikeNumber"]["value"]
        occupees = station["freeSlotNumber"]["value"]
        pourcentage = round((occupees / total) * 100, 2)

        resultats.append({
            "id": station["address"]["value"]["streetAddress"],
            "status": station["status"]["value"],
            "temps": temps,
            "place": {
                "velo_total": total,
                "velos_occupee": occupees,
                "velos_disponibles": disponibles,
                "occupation": f"{pourcentage}%"
            }
        })

        total_ville += total
        occupees_ville += occupees
        disponibles_ville += disponibles

    # Résumé global pour Montpellier
    pourcent_global = round((occupees_ville / total_ville) * 100, 2)
    resultats.append({
        "type": "Montpellier",
        "temps": temps,
        "place": {
            "velo_total": total_ville,
            "velos_occupee": occupees_ville,
            "velos_disponibles": disponibles_ville,
            "occupation": f"{pourcent_global}%"
        }
    })

    return resultats


def sauvegarder_donnees(resultats: list[dict]) -> None:
    """Ajoute les résultats au fichier JSON existant."""
    contenu = []
    if FICHIER_SORTIE.exists():
        try:
            contenu = json.loads(FICHIER_SORTIE.read_text(encoding="utf8"))
        except json.JSONDecodeError:
            contenu = []

    contenu.extend(resultats)
    FICHIER_SORTIE.write_text(
        json.dump(contenu, indent=4, ensure_ascii=False),
        encoding="utf8"
    )


def main():
    """Point d'entrée principal du monitoring."""
    intervalle_secondes = INTERVALLE_HEURES * 3600
    nb_mesures = (DUREE_JOURS * 24 * 3600) // intervalle_secondes

    for i in range(nb_mesures):
        temps_actuel = formater_date(time.time())
        data = recuperer_donnees_velos()
        resultats = analyser_stations(data, temps_actuel)
        sauvegarder_donnees(resultats)

        print(f"Mesure vélo {i + 1} enregistrée à {temps_actuel}")

        if i < nb_mesures - 1:
            time.sleep(intervalle_secondes - 1)


if __name__ == "__main__":
    main()