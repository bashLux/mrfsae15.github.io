import json
import re
from pathlib import Path
from collections import defaultdict


def sanitize_variable_name(name: str) -> str:
    
    sanitized = name.replace(" ", "_").replace("-", "_").replace("'", "_")
    return re.sub(r'[^\w]', '', sanitized)


def extract_occupation_data(raw_data: list) -> dict[str, list[float]]:
    
    grouped_data = defaultdict(list)
    
    for entry in raw_data:
        object_id = entry.get("id") or entry.get("type")
        
        if object_id and "place" in entry:
            occupation_str = entry["place"]["occupation"]
            occupation_value = float(occupation_str.replace('%', ''))
            grouped_data[object_id].append(occupation_value)
    
    return dict(grouped_data)


def write_python_file(data: dict[str, list[float]], output_path: Path) -> None:
    
    lines = ["# Fichier de données généré automatiquement\n"]
    
    for name, values in data.items():
        var_name = sanitize_variable_name(name)
        lines.append(f"{var_name} = {values}")
    
    output_path.write_text("\n".join(lines), encoding="utf8")


def convert_json_to_python(source_file: str, output_file: str) -> None:
    
    try:
        raw_data = json.loads(Path(source_file).read_text(encoding="utf8"))
        occupation_data = extract_occupation_data(raw_data)
        write_python_file(occupation_data, Path(output_file))
        print(f"Termine ! Le fichier '{output_file}' est pret.")
    except Exception as error:
        print(f"Erreur : {error}")
        
if __name__ == "__main__":
    convert_json_to_python("donnees_parking.json", "donnees_parking.py")
    convert_json_to_python("donnees_velos.json", "donnees_velo.py")