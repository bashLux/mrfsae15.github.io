import json
import matplotlib.pyplot as plt
from datetime import datetime


FICHIER_JSON = "donnees_parking.json"


def afficher_occupation_parking(nom_parking):
    try:
        with open(FICHIER_JSON, "r", encoding="utf-8") as f:
            donnees = json.load(f)
    except Exception as e:
        print("Erreur lors de l'ouverture du fichier :", e)
        return

    if not isinstance(donnees, list):
        print("Erreur : format JSON invalide.")
        return

    mesures = []

    for ligne in donnees:
        if not isinstance(ligne, dict):
            continue

        if ligne.get("id") != nom_parking:
            continue

        try:
            date_heure = datetime.strptime(
                ligne.get("temps", ""),
                "%d/%m/%Y %H:%M:%S"
            )

            occupation_txt = ligne.get("place", {}).get("occupation", "")
            occupation = float(occupation_txt.replace("%", ""))

            mesures.append((date_heure, occupation))

        except Exception:
            continue

    if not mesures:
        print(f"Aucune donnée trouvée pour le parking : {nom_parking}")
        return

    # Tri chronologique
    mesures.sort(key=lambda x: x[0])
    dates, occupations = zip(*mesures)

    # Graphe
    plt.figure(figsize=(10, 5))
    plt.plot(dates, occupations, color="red", linewidth=2)
    plt.scatter(dates, occupations, color="black", s=12)

    plt.title(f"Occupation du parking {nom_parking}")
    plt.xlabel("Date et heure")
    plt.ylabel("Occupation (%)")
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()
    plt.show()


# Programme principal
parking_demande = input("Nom du parking à afficher : ")
afficher_occupation_parking(parking_demande)
